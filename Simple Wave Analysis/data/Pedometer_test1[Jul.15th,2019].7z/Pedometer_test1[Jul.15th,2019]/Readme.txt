Abbreviations:
RRW��Ruanxi_Right-hand_Walk
RLW��Ruanxi_Left-hand_Walk
JRW��Jiangsuya_Right-hand_Walk
JLW��Jiangsuya_Left-hand_Walk
RRS:Ruanxi_Right-hand_Stair
JLS:Jiangsuya_Left-hand_Stair
RRR:Ruanxi_Right-hand_Run

